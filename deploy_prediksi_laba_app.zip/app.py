import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from io import BytesIO
import datetime
from collections import deque

st.set_page_config(page_title="Prediksi Laba Asuransi", layout="wide")
st.title("📊 Prediksi Pertumbuhan Laba Asuransi")

st.markdown("""
Aplikasi ini menggunakan model **Ridge Regression** untuk memprediksi pertumbuhan laba perusahaan berdasarkan:
- **Premi**
- **Beban Klaim**
""")

# ==== Default Data ====
default_data = {
    'Keterangan': [
        'Jaminan Penawaran',
        'Jaminan Pelaksanaan',
        'Jaminan Pembayaran Uang Muka',
        'Jaminan Pemeliharaan'
    ],
    'Premi': [25550305, 510017770, 333014598, 293668804],
    'Beban Klaim': [129770292, 839433085, 648851462, 259540585],
    'Pertumbuhan Laba': [1.07024e+08, 5.733209e+08, 4.270374e+08, 2.729670e+08]
}
df = pd.DataFrame(default_data)

# ==== Latih model dasar ====
X = df[['Premi', 'Beban Klaim']]
y = df['Pertumbuhan Laba']
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
model = Ridge(alpha=1.0)
model.fit(X_scaled, y)

# Riwayat prediksi selama sesi
if "riwayat" not in st.session_state:
    st.session_state.riwayat = deque(maxlen=50)

# ==== Upload File ====
st.subheader("📂 Upload File Excel (Opsional)")
uploaded_file = st.file_uploader("Unggah file Excel berisi data 'Premi' dan 'Beban Klaim'", type=["xlsx"])

if uploaded_file:
    try:
        input_df = pd.read_excel(uploaded_file)
        if 'Premi' in input_df.columns and 'Beban Klaim' in input_df.columns:
            input_scaled = scaler.transform(input_df[['Premi', 'Beban Klaim']])
            input_df['Prediksi Laba'] = model.predict(input_scaled)

            st.success("✅ Prediksi berhasil dihitung!")
            st.dataframe(input_df)

            # Download link
            def to_excel(df):
                output = BytesIO()
                writer = pd.ExcelWriter(output, engine='xlsxwriter')
                df.to_excel(writer, index=False, sheet_name='Prediksi')
                writer.save()
                return output.getvalue()

            st.download_button(
                label="📥 Unduh Hasil Prediksi (.xlsx)",
                data=to_excel(input_df),
                file_name="hasil_prediksi_laba.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

            if 'Tanggal' in input_df.columns:
                input_df['Tanggal'] = pd.to_datetime(input_df['Tanggal'])
                st.subheader("📆 Tren Waktu Premi dan Klaim")
                fig_time = px.line(
                    input_df.sort_values("Tanggal"),
                    x="Tanggal",
                    y=["Premi", "Beban Klaim", "Prediksi Laba"],
                    markers=True,
                    title="Perkembangan Premi, Klaim dan Prediksi Laba dari Waktu ke Waktu"
                )
                st.plotly_chart(fig_time, use_container_width=True)

        else:
            st.error("❌ File harus mengandung kolom: 'Premi' dan 'Beban Klaim'")
    except Exception as e:
        st.error(f"❌ Gagal memproses file: {e}")
else:
    # ==== Input Manual ====
    st.header("🧾 Input Data Manual")
    col1, col2 = st.columns(2)
    with col1:
        input_premi = st.number_input("Premi", min_value=0.0, value=100000000.0, step=1000000.0)
    with col2:
        input_klaim = st.number_input("Beban Klaim", min_value=0.0, value=150000000.0, step=1000000.0)

    input_scaled = scaler.transform([[input_premi, input_klaim]])
    prediksi_laba = model.predict(input_scaled)[0]
    st.metric("💰 Prediksi Laba", f"Rp {prediksi_laba:,.0f}")

    waktu_input = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    st.session_state.riwayat.append({
        "Waktu": waktu_input,
        "Premi": input_premi,
        "Beban Klaim": input_klaim,
        "Prediksi Laba": prediksi_laba
    })

    # Tampilkan data default dengan prediksi
    df['Prediksi Laba'] = model.predict(X_scaled)
    st.subheader("📋 Data Historis & Prediksi")
    st.dataframe(df)

    # Grafik Plotly
    st.subheader("📈 Grafik Interaktif")
    fig = px.scatter(
        df,
        x='Premi',
        y='Pertumbuhan Laba',
        size='Beban Klaim',
        color='Keterangan',
        hover_name='Keterangan',
        title="Hubungan Premi dan Pertumbuhan Laba",
        labels={'Premi': 'Premi', 'Pertumbuhan Laba': 'Laba'},
        size_max=40
    )
    st.plotly_chart(fig, use_container_width=True)

# Tampilkan riwayat
st.subheader("🕒 Riwayat Prediksi Sesi Ini")
if st.session_state.riwayat:
    riwayat_df = pd.DataFrame(st.session_state.riwayat)
    st.dataframe(riwayat_df)

    def to_excel_riwayat(df):
        output = BytesIO()
        writer = pd.ExcelWriter(output, engine='xlsxwriter')
        df.to_excel(writer, index=False, sheet_name='Riwayat')
        writer.save()
        return output.getvalue()

    st.download_button(
        "📥 Unduh Riwayat Prediksi (.xlsx)",
        data=to_excel_riwayat(riwayat_df),
        file_name="riwayat_prediksi_laba.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
else:
    st.info("Belum ada riwayat prediksi.")

st.caption("Dibuat dengan data aktual dan ❤️ oleh ChatGPT")